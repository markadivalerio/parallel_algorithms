#include <iostream>
#include <omp.h>
#include <cmath>
#include "hw1.h"

double euclidean_length(std::vector<double> vector) {
  // Your code goes here.
  double total = 0.0;
  #pragma opm parallel for reduction(+:total)
  for(int n=0; n<vector.size(); n++) {
    total += vector[n]*vector[n];
  }
  return sqrt(total);
}


std::vector<int64_t> discard_duplicates(std::vector<int64_t> sorted_vector) {
  // Your code goes here
  //std::vector<int64_t> unique = std::vector<int64_t>();
  std::vector<int> indexes = std::vector<int>(sorted_vector.size(), 0);
  //std::vector<int> indexes2 = std::vector<int>(sorted_vector.size(), 0);
  //std::vector<int> indexes3 = std::vector<int>(sorted_vector.size(), 0);
  int i, n, val, d, max;
  n = sorted_vector.size();
  indexes[0] = 1;
  #pragma opm parallel for default(shared) private(i)
  for(i=1; i<n; i++) {
    if(sorted_vector[i] != sorted_vector[i-1])
      indexes[i] = 1;
  }

  
  for (auto i = indexes.begin(); i != indexes.end(); ++i)
    std::cout << *i << ' ';
  std::cout << std::endl;

  
  // parallel prefix
  /*
  #pragma opm parallel for default(shared) private(i)
  for(i=1; i < n/2; i++) {
    indexes2[i] = indexes[2*i] + indexes[2*i - 1]
  }

  for(d=1; d<n; d=2*d) {
    #pragma opm parallel for default(shared) private(i, val)
    for(i=1; i<n; i++) {
      if(i>=d)
        val = indexes[i-d];
      #pragma opm barrier  
      if(i>=d)
        indexes[i] = indexes[i] + val;
      #pragma opm barrier
    }
  }
  */
  
  for(i=1; i<n; i++){
    indexes[i] = indexes[i] + indexes[i-1];
  }


  max = indexes[n-1];
  std::vector<int64_t> unique = std::vector<int64_t>(max);
  
  for (auto i = indexes.begin(); i != indexes.end(); ++i)
    std::cout << *i << ' ';
  std::cout << std::endl;
  
  #pragma opm parallel for default(shared) private(i, val)
  for(i=0; i<n; i++) {
    val = indexes[i] - 1;
    unique[val] = sorted_vector[i];
  }
 
  return unique;
}

